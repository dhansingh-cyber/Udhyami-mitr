# उद्यमी मित्र — GitHub से APK कैसे बनाएं (बिना Android Studio के)

यह तरीका सबसे आसान है — आपको सिर्फ GitHub account चाहिए, कंप्यूटर में कुछ भी install
करने की ज़रूरत नहीं। पूरी APK GitHub के cloud servers पर अपने आप बन जाएगी।

---

## Step 1: GitHub Repository बनाएं

1. https://github.com पर जाकर account बना लें (अगर पहले से नहीं है)
2. ऊपर right corner में **"+"** → **"New repository"** पर क्लिक करें
3. Repository name डालें: `udyami-mitra-app`
4. **Public** या **Private** — दोनों चलेगा
5. **Create repository** पर क्लिक करें

---

## Step 2: इस project के files upload करें

Repository बनने के बाद जो page खुलेगा उसमें लिखा होगा
**"uploading an existing file"** — उस लिंक पर क्लिक करें।

फिर:
1. मैंने जो ZIP फ़ाइल दी है उसे अपने कंप्यूटर में extract करें
2. `udyami-mitra-app` फ़ोल्डर के अंदर की **सारी फाइलें और फ़ोल्डर्स**
   (package.json, capacitor.config.json, www, .github, README, .gitignore)
   को GitHub के upload वाले page पर drag-and-drop कर दें
3. नीचे **"Commit changes"** बटन दबा दें

> ⚠️ ध्यान रखें: `.github` फ़ोल्डर ज़रूर upload हो — इसी में build करने वाली automation है।
> कई बार browser hidden folder (जिसका नाम dot `.` से शुरू होता है) drag-drop में miss कर देता है।
> अगर `.github` folder upload ना हो, तो GitHub पर ही:
> - **"Add file" → "Create new file"** पर क्लिक करें
> - नाम में टाइप करें: `.github/workflows/build-apk.yml`
> - मेरे दिए गए `build-apk.yml` का पूरा content paste कर दें और commit कर दें

---

## Step 3: Build अपने आप शुरू हो जाएगी

Commit करते ही GitHub अपने आप APK बनाना शुरू कर देगा।

1. Repository के ऊपर मेनू में **"Actions"** टैब पर क्लिक करें
2. आपको एक running workflow दिखेगा (पीला/नारंगी dot घूमता हुआ) — नाम होगा
   **"Build Android APK"**
3. 3-5 मिनट में यह हरा ✅ (green tick) हो जाएगा

---

## Step 4: APK डाउनलोड करें

1. उसी completed workflow पर क्लिक करें
2. नीचे scroll करें **"Artifacts"** section तक
3. **"udyami-mitra-debug-apk"** पर क्लिक करके ZIP डाउनलोड करें
4. उसे extract करें — अंदर आपकी `app-debug.apk` मिल जाएगी

बस! यह फ़ाइल अपने Android फ़ोन में भेज कर install कर लें
(Settings में "Install from unknown sources" allow करना पड़ सकता है)।

---

## अगर Build fail (लाल ❌) हो जाए

**"Actions"** टैब में उस failed run पर क्लिक करें, फिर लाल cross वाले step पर
क्लिक करें — वहां error message दिखेगा। वो message मुझे यहां भेज दें, मैं ठीक कर दूंगा।

---

## भविष्य में अपडेट कैसे करें

जब भी website में कुछ बदलाव हो और आप नई APK चाहें, तो बस GitHub repo में कोई भी
छोटी सी file फिर से commit कर दें (या **Actions → Build Android APK → Run workflow**
बटन दबाएं) — नई APK अपने आप बन जाएगी।
