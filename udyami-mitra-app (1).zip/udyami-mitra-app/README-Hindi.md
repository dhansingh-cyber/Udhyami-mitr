# उद्यमी मित्र — Android APK कैसे बनाएं

यह एक तैयार Capacitor project है जो आपकी live website
`https://https-udyami-sahayak-connect-lovable-app.lovable.app`
को Android app (APK) के अंदर wrap करता है।

⚠️ ज़रूरी बात: APK फ़ाइल असल में बनाने के लिए Android SDK / Gradle की ज़रूरत होती है,
जो सिर्फ आपके कंप्यूटर (Android Studio) या किसी online build service में होता है।
इसलिए यहाँ मैंने पूरा project code तैयार करके दिया है — आपको बस नीचे दिए स्टेप्स फॉलो करने हैं,
5-10 मिनट में आपकी APK बन जाएगी।

---

## ज़रूरी चीज़ें (एक बार install करें)

1. **Node.js** install करें: https://nodejs.org (LTS version)
2. **Android Studio** install करें: https://developer.android.com/studio

---

## Steps (कमांड लाइन / टर्मिनल में)

1. इस फ़ोल्डर (`udyami-mitra-app`) को अपने कंप्यूटर में extract/copy करें।

2. टर्मिनल खोलें और इस फ़ोल्डर में जाएं:
   ```
   cd udyami-mitra-app
   ```

3. Dependencies install करें:
   ```
   npm install
   ```

4. Android platform जोड़ें:
   ```
   npx cap add android
   ```

5. Sync करें:
   ```
   npx cap sync
   ```

6. Android Studio में खोलें:
   ```
   npx cap open android
   ```

7. Android Studio खुलने के बाद, ऊपर मेनू में जाएं:
   **Build → Build Bundle(s) / APK(s) → Build APK(s)**

8. Build पूरा होने पर, नीचे notification में **"locate"** लिंक पर क्लिक करें —
   आपकी APK यहाँ मिलेगी:
   ```
   android/app/build/outputs/apk/debug/app-debug.apk
   ```

9. यह APK फ़ाइल अपने Android फ़ोन में भेज दें और install कर लें
   (Settings में "Install from unknown sources" allow करना पड़ सकता है)।

---

## नोट

- यह app असल में आपकी live website को ही अंदर load करता है (WebView की तरह),
  तो internet connection चाहिए होगा app चलाने के लिए।
- App का नाम "Udyami Mitra" और Package ID `com.udyamimitra.app` रखा गया है —
  अगर बदलना हो तो `capacitor.config.json` में बदल सकते हैं।
- Play Store पर publish करने के लिए **signed release APK/AAB** बनानी होगी
  (Android Studio में hi ये option milta hai: Build → Generate Signed Bundle/APK).
